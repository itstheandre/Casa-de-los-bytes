# Find Hidden Treasures 
> Maze Arcade Game inspired by PacMan

![screenshot](assets/gameboard.png)

## How to play
Easy! Click "the game controller icon🎮" to start/restart the game!
And just use arrow keys on your laptop to let the mini Super Minion move!!

*Watch out the 3 well-trained guards..

KEY :←↑→↓ 

MISSION :
 1 : Find the Access Key to TREASURES
 2 : Evade 3 Trained Guards
 3 : Find the Way to Reach TREASURE Room

TIME LIMIT : 1 min

## Demo

Have fun ☞ [DEMO](https://manamimonito.github.io/MyProjectIronhack/)


